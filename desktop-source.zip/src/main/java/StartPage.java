import com.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.security.SecureRandom;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class StartPage extends JFrame {

    private static final String CAPTCHA_CHARACTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    private final JLabel captchaLabel = new JLabel("", SwingConstants.CENTER);
    private final JLabel feedbackLabel = new JLabel(" ", SwingConstants.CENTER);
    private final JTextField responseField = new JTextField();
    private String captcha;

    public StartPage() {
        initialize();
        refreshCaptcha();
    }

    private void initialize() {
        setTitle("Password Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(560, 450));
        setPreferredSize(new Dimension(620, 500));

        JPanel root = new JPanel(new BorderLayout(0, 24));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(36, 48, 30, 48));

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel brand = new JLabel("Password Manager");
        brand.setFont(Theme.TITLE_FONT);
        brand.setForeground(Theme.TEXT);
        brand.setAlignmentX(LEFT_ALIGNMENT);

        JLabel description = new JLabel("Your credentials, organized and protected.");
        description.setFont(Theme.BODY_FONT);
        description.setForeground(Theme.MUTED);
        description.setAlignmentX(LEFT_ALIGNMENT);
        header.add(brand);
        header.add(Box.createVerticalStrut(8));
        header.add(description);

        JPanel card = new JPanel();
        card.setBackground(Theme.CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(22, 24, 22, 24)));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("Quick verification");
        heading.setFont(Theme.HEADING_FONT);
        heading.setForeground(Theme.TEXT);
        heading.setAlignmentX(LEFT_ALIGNMENT);

        JLabel instructions = new JLabel("Enter the code below to continue to sign in.");
        instructions.setFont(Theme.BODY_FONT);
        instructions.setForeground(Theme.MUTED);
        instructions.setAlignmentX(LEFT_ALIGNMENT);

        captchaLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        captchaLabel.setForeground(Theme.PRIMARY);
        captchaLabel.setBackground(Theme.INPUT);
        captchaLabel.setOpaque(true);
        captchaLabel.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        captchaLabel.setPreferredSize(new Dimension(230, 56));
        captchaLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        captchaLabel.setAlignmentX(LEFT_ALIGNMENT);
        captchaLabel.getAccessibleContext().setAccessibleName("Verification code");

        JButton refreshButton = new JButton("New code");
        Theme.styleSecondaryButton(refreshButton);
        refreshButton.setAlignmentX(LEFT_ALIGNMENT);
        refreshButton.addActionListener(event -> refreshCaptcha());

        JLabel responseLabel = new JLabel("Verification code");
        responseLabel.setFont(Theme.BODY_FONT);
        responseLabel.setForeground(Theme.TEXT);
        responseLabel.setAlignmentX(LEFT_ALIGNMENT);

        Theme.styleTextField(responseField);
        responseField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        responseField.setAlignmentX(LEFT_ALIGNMENT);
        responseField.setToolTipText("Type the code shown above");
        responseField.getAccessibleContext().setAccessibleName("Verification code entry");

        feedbackLabel.setFont(Theme.BODY_FONT);
        feedbackLabel.setForeground(Theme.DANGER);
        feedbackLabel.setAlignmentX(LEFT_ALIGNMENT);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(LEFT_ALIGNMENT);
        JButton continueButton = new JButton("Continue to sign in");
        Theme.styleButton(continueButton);
        continueButton.addActionListener(event -> verifyCaptcha());
        JButton exitButton = new JButton("Exit");
        Theme.styleSecondaryButton(exitButton);
        exitButton.addActionListener(event -> dispose());
        buttons.add(continueButton);
        buttons.add(exitButton);
        responseField.addActionListener(event -> verifyCaptcha());

        card.add(heading);
        card.add(Box.createVerticalStrut(6));
        card.add(instructions);
        card.add(Box.createVerticalStrut(18));
        card.add(captchaLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(refreshButton);
        card.add(Box.createVerticalStrut(18));
        card.add(responseLabel);
        card.add(Box.createVerticalStrut(6));
        card.add(responseField);
        card.add(Box.createVerticalStrut(8));
        card.add(feedbackLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(buttons);

        JLabel footer = new JLabel("Verification is required before opening your account.",
                SwingConstants.CENTER);
        footer.setFont(Theme.BODY_FONT);
        footer.setForeground(Theme.MUTED);

        root.add(header, BorderLayout.NORTH);
        root.add(card, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
        getRootPane().setDefaultButton(continueButton);
        pack();
        setLocationRelativeTo(null);
    }

    private void refreshCaptcha() {
        StringBuilder code = new StringBuilder(6);
        for (int index = 0; index < 6; index++) {
            code.append(CAPTCHA_CHARACTERS.charAt(RANDOM.nextInt(CAPTCHA_CHARACTERS.length())));
        }
        captcha = code.toString();
        captchaLabel.setText(captcha);
        responseField.setText("");
        feedbackLabel.setText(" ");
    }

    private void verifyCaptcha() {
        if (!captcha.equalsIgnoreCase(responseField.getText().trim())) {
            feedbackLabel.setText("That code did not match. Try again or request a new code.");
            responseField.selectAll();
            responseField.requestFocusInWindow();
            return;
        }

        new LoginForm().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new StartPage().setVisible(true));
    }
}
