import com.AddPass1;
import com.Connectionprovider;
import com.EncryptPage;
import com.GeneratePass;
import com.ShowTable;
import com.StrengthCheck;
import com.Theme;
import com.WindowNavigation;
import com.SecurityWordCredential;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

public class PasswordPage extends JFrame {

    private static final Logger LOGGER = Logger.getLogger(PasswordPage.class.getName());
    private final String username;

    public PasswordPage() {
        this("");
    }

    public PasswordPage(String username) {
        this.username = username == null ? "" : username.trim();
        initComponents();
    }

    private void initComponents() {
        setTitle("Password Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(640, 540));
        setPreferredSize(new Dimension(760, 640));

        JPanel root = new JPanel(new BorderLayout(0, 28));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(32, 40, 28, 40));

        JPanel header = new JPanel(new BorderLayout(12, 8));
        header.setOpaque(false);

        JPanel titlePanel = new JPanel(new BorderLayout(0, 6));
        titlePanel.setOpaque(false);
        JLabel title = new JLabel("Your password vault");
        title.setFont(Theme.TITLE_FONT);
        title.setForeground(Theme.TEXT);
        JLabel subtitle = new JLabel("Manage your credentials securely in one place.");
        subtitle.setFont(Theme.BODY_FONT);
        subtitle.setForeground(Theme.MUTED);
        titlePanel.add(title, BorderLayout.NORTH);
        titlePanel.add(subtitle, BorderLayout.SOUTH);

        JPanel accountPanel = new JPanel(new BorderLayout(12, 0));
        accountPanel.setOpaque(false);
        JLabel account = new JLabel(
                this.username.isEmpty() ? "Welcome" : "Signed in as " + this.username);
        account.setFont(Theme.BODY_FONT);
        account.setForeground(Theme.MUTED);
        JButton logout = new JButton("Log out");
        Theme.styleSecondaryButton(logout);
        logout.addActionListener(event -> logOut());
        accountPanel.add(account, BorderLayout.CENTER);
        accountPanel.add(logout, BorderLayout.EAST);

        header.add(titlePanel, BorderLayout.NORTH);
        header.add(accountPanel, BorderLayout.SOUTH);

        JPanel content = new JPanel(new BorderLayout(0, 14));
        content.setOpaque(false);
        JLabel sectionTitle = new JLabel("Vault tools");
        sectionTitle.setFont(Theme.HEADING_FONT);
        sectionTitle.setForeground(Theme.TEXT);
        content.add(sectionTitle, BorderLayout.NORTH);

        JPanel actions = new JPanel(new GridLayout(0, 2, 14, 14));
        actions.setOpaque(false);
        actions.add(createActionButton("Add a password", "Save a new website or app credential",
                this::openAddPassword));
        actions.add(createActionButton("View saved passwords", "Search and review your vault",
                this::openSavedPasswords));
        actions.add(createActionButton("Generate a password", "Create a strong, random password",
                this::openPasswordGenerator));
        actions.add(createActionButton("Check password strength", "Review a password before using it",
                this::openStrengthChecker));
        actions.add(createActionButton("Decrypt a password", "Continue with your security word",
                this::verifySecurityWord));
        content.add(actions, BorderLayout.CENTER);

        JLabel footer = new JLabel("Your vault stays private to your account.", SwingConstants.CENTER);
        footer.setFont(Theme.BODY_FONT);
        footer.setForeground(Theme.MUTED);

        root.add(header, BorderLayout.NORTH);
        root.add(content, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton createActionButton(String title, String description, Runnable action) {
        JButton button = new JButton("<html><div style='text-align:left;padding:4px 8px'>"
                + "<b>" + title + "</b><br><span style='font-size:small;color:#94a3b8'>"
                + description + "</span></div></html>");
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setPreferredSize(new Dimension(280, 90));
        Theme.styleSecondaryButton(button);
        button.addActionListener(event -> action.run());
        return button;
    }

    private void openAddPassword() {
        AddPass1 window = new AddPass1(username);
        WindowNavigation.showChild(this, window);
    }

    private void openSavedPasswords() {
        ShowTable window = new ShowTable(username);
        WindowNavigation.showChild(this, window);
    }

    private void openPasswordGenerator() {
        GeneratePass window = new GeneratePass();
        WindowNavigation.showChild(this, window);
    }

    private void openStrengthChecker() {
        StrengthCheck window = new StrengthCheck();
        WindowNavigation.showChild(this, window);
    }

    private void verifySecurityWord() {
        JPasswordField securityWordField = new JPasswordField(18);
        int choice = JOptionPane.showConfirmDialog(
                this,
                securityWordField,
                "Enter your security word to continue.",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }

        char[] candidate = securityWordField.getPassword();
        try {
            if (candidate.length == 0) {
                return;
            }

            String storedCredential;
            String selectSql = "SELECT SecurityWord FROM user WHERE username = ?";
            try (Connection connection = Connectionprovider.getCon()) {
                if (connection == null) {
                    throw new SQLException("Database connection is unavailable.");
                }
                try (PreparedStatement statement = connection.prepareStatement(selectSql)) {
                    statement.setString(1, username);
                    try (ResultSet result = statement.executeQuery()) {
                        if (!result.next()) {
                            showSecurityWordMismatch();
                            return;
                        }
                        storedCredential = result.getString("SecurityWord");
                    }
                }

                if (!SecurityWordCredential.verify(candidate, storedCredential)) {
                    showSecurityWordMismatch();
                    return;
                }

                if (!SecurityWordCredential.isHashed(storedCredential)) {
                    String updateSql = "UPDATE user SET SecurityWord = ? "
                            + "WHERE username = ? AND SecurityWord = ?";
                    try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
                        statement.setString(1, SecurityWordCredential.hash(candidate));
                        statement.setString(2, username);
                        statement.setString(3, storedCredential);
                        statement.executeUpdate();
                    }
                }
            }

            EncryptPage window = new EncryptPage(username);
            WindowNavigation.showChild(this, window);
        } catch (ClassNotFoundException | SQLException exception) {
            LOGGER.log(Level.SEVERE, "Could not verify security word", exception);
            JOptionPane.showMessageDialog(
                    this,
                    "Could not verify your security word. Check the database connection and try again.",
                    "Verification error",
                    JOptionPane.ERROR_MESSAGE);
        } finally {
            java.util.Arrays.fill(candidate, '\0');
            securityWordField.setText("");
        }
    }

    private void showSecurityWordMismatch() {
        JOptionPane.showMessageDialog(
                this,
                "The security word did not match.",
                "Verification failed",
                JOptionPane.WARNING_MESSAGE);
    }

    private void logOut() {
        WindowNavigation.replace(this, new LoginForm());
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new PasswordPage().setVisible(true));
    }
}
