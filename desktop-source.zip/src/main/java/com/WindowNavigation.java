package com;

import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

public final class WindowNavigation {

    private static final String RETURN_WINDOW_PROPERTY = WindowNavigation.class.getName() + ".returnWindow";

    private WindowNavigation() {
    }

    public static void showChild(JFrame current, JFrame next) {
        prepareNextWindow(current, next);
        next.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        next.getRootPane().putClientProperty(RETURN_WINDOW_PROPERTY, current);
        next.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent event) {
                if (current.isDisplayable()) {
                    current.setVisible(true);
                    current.toFront();
                }
            }
        });
        current.setVisible(false);
        next.setVisible(true);
    }

    public static void replace(JFrame current, JFrame next) {
        prepareNextWindow(current, next);
        next.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        disposeReturnChain(current);
        current.dispose();
        next.setVisible(true);
    }

    private static void disposeReturnChain(JFrame window) {
        Object parent = window.getRootPane().getClientProperty(RETURN_WINDOW_PROPERTY);
        while (parent instanceof JFrame) {
            JFrame parentFrame = (JFrame) parent;
            parent = parentFrame.getRootPane().getClientProperty(RETURN_WINDOW_PROPERTY);
            if (parentFrame.isDisplayable()) {
                parentFrame.dispose();
            }
        }
    }

    private static void prepareNextWindow(JFrame current, JFrame next) {
        int state = current.getExtendedState();
        Rectangle bounds = current.getBounds();
        next.setBounds(bounds);
        next.setExtendedState(state);
    }
}
