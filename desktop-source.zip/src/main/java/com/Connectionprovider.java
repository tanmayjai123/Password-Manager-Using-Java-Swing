
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connectionprovider {

    public static Connection getCon()
            throws ClassNotFoundException, SQLException {

        String url = System.getenv("DB_URL");
        String username = System.getenv("DB_USER");
        String password = System.getenv("DB_PASSWORD");

        if (url == null || username == null || password == null
                || url.isBlank() || username.isBlank() || password.isBlank()) {
            throw new SQLException(
                    "Database configuration missing. Set DB_URL, DB_USER and DB_PASSWORD.");
        }

        Class.forName("com.mysql.cj.jdbc.Driver");

        return DriverManager.getConnection(url, username, password);
    }
}
