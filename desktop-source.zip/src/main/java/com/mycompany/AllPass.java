
package com.mycompany;

import com.AddPass1;
import com.Connectionprovider;
import com.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import net.proteanit.sql.DbUtils;

public class AllPass extends JFrame {

    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;

    public AllPass() {
        initComponents();
        applyDarkTheme();
        loadPasswords();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Password Vault");
        setSize(1000, 600);
        setMinimumSize(new Dimension(750, 450));

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(Theme.BACKGROUND);
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(25, 25, 25, 25));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout(10, 5));
        headerPanel.setBackground(Theme.SIDEBAR);
        headerPanel.setBorder(
                BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel titlePanel = new JPanel(new BorderLayout(5, 5));
        titlePanel.setBackground(Theme.SIDEBAR);

        jLabel1.setText("PASSWORD VAULT");
        jLabel1.setFont(Theme.TITLE_FONT);
        jLabel1.setForeground(Theme.TEXT);

        jLabel3.setText("Your stored account credentials");
        jLabel3.setFont(Theme.BODY_FONT);
        jLabel3.setForeground(Theme.MUTED);

        titlePanel.add(jLabel1, BorderLayout.NORTH);
        titlePanel.add(jLabel3, BorderLayout.SOUTH);

        headerPanel.add(titlePanel, BorderLayout.CENTER);

        jButton1.setText("+ Add Password");
        jButton1.addActionListener(evt -> openAddPassword());
        Theme.styleButton(jButton1);
        headerPanel.add(jButton1, BorderLayout.EAST);

        // Table
        jTable1.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] {
                        "Record ID", "Account Username",
                        "Encrypted Password", "Application", "Login User"
                }) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        jTable1.setRowHeight(34);
        jTable1.setFont(Theme.BODY_FONT);
        jTable1.setForeground(Theme.TEXT);
        jTable1.setBackground(Theme.CARD);
        jTable1.setSelectionBackground(Theme.PRIMARY);
        jTable1.setSelectionForeground(java.awt.Color.WHITE);
        jTable1.setGridColor(Theme.BORDER);
        jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        jTable1.setFillsViewportHeight(true);
        jTable1.setShowGrid(true);
        jTable1.setIntercellSpacing(new Dimension(1, 1));

        JTableHeader tableHeader = jTable1.getTableHeader();
        tableHeader.setBackground(Theme.SIDEBAR);
        tableHeader.setForeground(Theme.TEXT);
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tableHeader.setPreferredSize(new Dimension(0, 38));
        tableHeader.setReorderingAllowed(false);

        jScrollPane1.setViewportView(jTable1);
        jScrollPane1.getViewport().setBackground(Theme.CARD);
        jScrollPane1.setBorder(
                BorderFactory.createLineBorder(Theme.BORDER));

        // Footer
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(Theme.BACKGROUND);

        jLabel4.setText("Stored records: 0");
        jLabel4.setFont(Theme.BODY_FONT);
        jLabel4.setForeground(Theme.MUTED);

        jLabel5.setText("Passwords remain encrypted in the database");
        jLabel5.setFont(Theme.BODY_FONT);
        jLabel5.setForeground(Theme.MUTED);
        jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);

        footerPanel.add(jLabel4, BorderLayout.WEST);
        footerPanel.add(jLabel5, BorderLayout.EAST);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(jScrollPane1, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void applyDarkTheme() {
        getContentPane().setBackground(Theme.BACKGROUND);
        jTable1.setBackground(Theme.CARD);
        jTable1.setForeground(Theme.TEXT);
        jTable1.setSelectionBackground(Theme.PRIMARY);
        jTable1.setSelectionForeground(java.awt.Color.WHITE);
        jTable1.setGridColor(Theme.BORDER);

        jTable1.getTableHeader().setBackground(Theme.SIDEBAR);
        jTable1.getTableHeader().setForeground(Theme.TEXT);

        Theme.styleButton(jButton1);
    }

    private void loadPasswords() {
        String query = "SELECT srno, USERNAME, ENCRYPTED_PASSWORD, APPLICATION, "
                + "LoginUsername FROM `idusnewjava` ORDER BY srno ASC";

        try (
                Connection con = Connectionprovider.getCon();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query)) {
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));

            // Prevent editing stored credential records in the table.
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

            jTable1.setModel(new DefaultTableModel(
                    copyRows(model),
                    getColumnNames(model)) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });

            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

            int[] widths = { 80, 180, 350, 180, 180 };

            for (int i = 0; i < jTable1.getColumnCount(); i++) {
                int width = widths[Math.min(i, widths.length - 1)];
                jTable1.getColumnModel()
                        .getColumn(i).setPreferredWidth(width);
            }

            jLabel4.setText(
                    "Stored records: " + jTable1.getRowCount());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to load saved passwords.\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private Object[][] copyRows(DefaultTableModel model) {
        Object[][] rows = new Object[model.getRowCount()][model.getColumnCount()];

        for (int row = 0; row < model.getRowCount(); row++) {
            for (int col = 0; col < model.getColumnCount(); col++) {
                rows[row][col] = model.getValueAt(row, col);
            }
        }

        return rows;
    }

    private Object[] getColumnNames(DefaultTableModel model) {
        Object[] names = new Object[model.getColumnCount()];

        for (int col = 0; col < model.getColumnCount(); col++) {
            names[col] = model.getColumnName(col);
        }

        return names;
    }

    private void openAddPassword() {
        new AddPass1().setVisible(true);
        dispose();
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(
                            info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(AllPass.class.getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new AllPass().setVisible(true));
    }
}
