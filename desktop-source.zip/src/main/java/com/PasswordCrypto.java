
package com;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordCrypto {

    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int IV_LENGTH = 12;
    private static final int TAG_LENGTH_BITS = 128;

    private PasswordCrypto() {
        // Utility class
    }

    private static SecretKeySpec getKey() {
        String encodedKey = System.getenv("PM_AES_KEY");

        if (encodedKey == null || encodedKey.isBlank()) {
            throw new IllegalStateException(
                    "PM_AES_KEY environment variable is missing.");
        }

        byte[] keyBytes = Base64.getDecoder().decode(encodedKey);

        if (keyBytes.length != 32) {
            throw new IllegalStateException(
                    "PM_AES_KEY must contain exactly 32 decoded bytes.");
        }

        return new SecretKeySpec(keyBytes, ALGORITHM);
    }

    public static String encrypt(String plainText) throws Exception {
        if (plainText == null) {
            throw new IllegalArgumentException("Plaintext cannot be null.");
        }

        byte[] iv = new byte[IV_LENGTH];
        new SecureRandom().nextBytes(iv);

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(
                Cipher.ENCRYPT_MODE,
                getKey(),
                new GCMParameterSpec(TAG_LENGTH_BITS, iv));

        byte[] encrypted = cipher.doFinal(
                plainText.getBytes(java.nio.charset.StandardCharsets.UTF_8));

        byte[] combined = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(
                encrypted, 0, combined, iv.length, encrypted.length);

        return "AESGCM:" + Base64.getEncoder().encodeToString(combined);
    }

    public static String decrypt(String encryptedText) throws Exception {
        if (encryptedText == null || !encryptedText.startsWith("AESGCM:")) {
            throw new IllegalArgumentException(
                    "Unsupported encrypted password format.");
        }

        byte[] combined = Base64.getDecoder().decode(
                encryptedText.substring("AESGCM:".length()));

        if (combined.length < IV_LENGTH + 16) {
            throw new IllegalArgumentException("Invalid encrypted data.");
        }

        byte[] iv = new byte[IV_LENGTH];
        byte[] ciphertext = new byte[combined.length - IV_LENGTH];

        System.arraycopy(combined, 0, iv, 0, IV_LENGTH);
        System.arraycopy(
                combined, IV_LENGTH, ciphertext, 0, ciphertext.length);

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(
                Cipher.DECRYPT_MODE,
                getKey(),
                new GCMParameterSpec(TAG_LENGTH_BITS, iv));

        byte[] plainBytes = cipher.doFinal(ciphertext);

        return new String(
                plainBytes, java.nio.charset.StandardCharsets.UTF_8);
    }
}
