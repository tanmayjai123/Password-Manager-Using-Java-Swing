
package com;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class EncryptPage extends JFrame {

    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JPasswordField jTextField2;
    private javax.swing.Timer clearPasswordTimer;
    private javax.swing.Timer hidePasswordTimer;

    public EncryptPage() {
        initComponents();
        applyDarkTheme();
        setLocationRelativeTo(null);
    }

    private void togglePasswordVisibility() {
        if (jTextField2.getPassword().length == 0) {
            return;
        }

        if (jTextField2.getEchoChar() == 0) {
            jTextField2.setEchoChar('\u2022');
            jButton5.setText("SHOW");
            if (hidePasswordTimer != null) {
                hidePasswordTimer.stop();
            }
        } else {
            jTextField2.setEchoChar((char) 0);
            jButton5.setText("HIDE");
            if (hidePasswordTimer != null) {
                hidePasswordTimer.stop();
            }
            hidePasswordTimer = new javax.swing.Timer(15000, event -> {
                jTextField2.setEchoChar('\u2022');
                jButton5.setText("SHOW");
            });
            hidePasswordTimer.setRepeats(false);
            hidePasswordTimer.start();
        }
    }

    private void startPasswordClearTimer() {
        if (clearPasswordTimer != null) {
            clearPasswordTimer.stop();
        }
        clearPasswordTimer = new javax.swing.Timer(30000, event -> {
            jTextField2.setText("");
            jTextField2.setEchoChar('\u2022');
            jButton5.setText("SHOW");
        });
        clearPasswordTimer.setRepeats(false);
        clearPasswordTimer.start();
    }

    public EncryptPage(String LUser) {
        initComponents();
        applyDarkTheme();
        jLabel5.setText(LUser);
        jLabel5.setVisible(true);
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Password Decryptor");
        setSize(700, 470);
        setResizable(false);
        getContentPane().setBackground(Theme.BACKGROUND);
        getContentPane().setLayout(null);

        // Header
        jPanel1.setBackground(Theme.SIDEBAR);
        jPanel1.setLayout(null);
        jPanel1.setBorder(
                BorderFactory.createMatteBorder(
                        0, 0, 1, 0, Theme.BORDER));

        jLabel1.setFont(Theme.TITLE_FONT);
        jLabel1.setForeground(Theme.TEXT);
        jLabel1.setText("DECRYPTOR");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(25, 12, 250, 45);

        jLabel5.setFont(Theme.BODY_FONT);
        jLabel5.setForeground(Theme.MUTED);
        jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
        jLabel5.setText("");
        jLabel5.setVisible(false);
        jPanel1.add(jLabel5);
        jLabel5.setBounds(450, 15, 210, 35);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 700, 70);

        // Encrypted input
        jLabel2.setFont(Theme.BODY_FONT);
        jLabel2.setForeground(Theme.MUTED);
        jLabel2.setText("ENCRYPTED PASSWORD");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(35, 100, 250, 25);

        jTextField1.setFont(Theme.BODY_FONT);
        jTextField1.setBackground(Theme.INPUT);
        jTextField1.setForeground(Theme.TEXT);
        jTextField1.setCaretColor(Theme.TEXT);
        jTextField1.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Theme.BORDER),
                        new EmptyBorder(8, 10, 8, 10)));
        jTextField1.addActionListener(evt -> decryptPassword());
        getContentPane().add(jTextField1);
        jTextField1.setBounds(35, 130, 625, 42);

        // Output label
        jLabel4.setFont(Theme.BODY_FONT);
        jLabel4.setForeground(Theme.MUTED);
        jLabel4.setText("DECRYPTED PASSWORD");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(35, 195, 250, 25);

        // Decrypted output
        jTextField2.setFont(Theme.BODY_FONT);
        jTextField2.setBackground(Theme.INPUT);
        jTextField2.setForeground(Theme.SUCCESS);
        jTextField2.setCaretColor(Theme.TEXT);
        jTextField2.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Theme.BORDER),
                        new EmptyBorder(8, 10, 8, 10)));
        jTextField2.setEchoChar('\u2022');
        getContentPane().add(jTextField2);
        jTextField2.setBounds(35, 225, 505, 42);

        jButton5.setText("SHOW");
        jButton5.addActionListener(evt -> togglePasswordVisibility());
        getContentPane().add(jButton5);
        jButton5.setBounds(550, 225, 110, 42);

        // Decrypt button
        jButton3.setText("DECRYPT");
        jButton3.addActionListener(evt -> decryptPassword());
        getContentPane().add(jButton3);
        jButton3.setBounds(35, 305, 150, 42);

        // Copy button
        jButton4.setText("COPY");
        jButton4.addActionListener(evt -> copyPassword());
        getContentPane().add(jButton4);
        jButton4.setBounds(215, 305, 150, 42);

        // Back button
        jButton1.setText("BACK");
        jButton1.addActionListener(evt -> dispose());
        getContentPane().add(jButton1);
        jButton1.setBounds(510, 305, 150, 42);

        // Background replaces old absolute-path image
        jLabel3.setOpaque(true);
        jLabel3.setBackground(Theme.BACKGROUND);
        jLabel3.setText("");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 70, 700, 370);
    }

    private void applyDarkTheme() {
        getContentPane().setBackground(Theme.BACKGROUND);
        jPanel1.setBackground(Theme.SIDEBAR);

        jLabel1.setForeground(Theme.TEXT);
        jLabel1.setFont(Theme.TITLE_FONT);

        jLabel2.setForeground(Theme.MUTED);
        jLabel4.setForeground(Theme.MUTED);

        jLabel3.setIcon(null);
        jLabel3.setText("");
        jLabel3.setOpaque(true);
        jLabel3.setBackground(Theme.BACKGROUND);

        jTextField1.setBackground(Theme.INPUT);
        jTextField1.setForeground(Theme.TEXT);
        jTextField1.setCaretColor(Theme.TEXT);
        jTextField1.setSelectionColor(Theme.PRIMARY);

        jTextField2.setBackground(Theme.INPUT);
        jTextField2.setForeground(Theme.SUCCESS);
        jTextField2.setCaretColor(Theme.TEXT);
        jTextField2.setSelectionColor(Theme.PRIMARY);

        Theme.styleButton(jButton3);
        Theme.styleButton(jButton4);
        Theme.styleSecondaryButton(jButton5);
        Theme.styleSecondaryButton(jButton1);
    }

    private void decryptPassword() {
        String input = jTextField1.getText().trim();

        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Enter an encrypted password.",
                    "Input Required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String decrypted = decrypt(input);
            jTextField2.setText(decrypted);
            jTextField2.setEchoChar('\u2022');
            jButton5.setText("SHOW");
            startPasswordClearTimer();
        } catch (Exception ex) {
            jTextField2.setText("");
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to decrypt this password. Check the encryption key and input.",
                    "Decryption Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void copyPassword() {
        String text = jTextField2.getText();

        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Decrypt a password before copying it.",
                    "Nothing to Copy",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            StringSelection selection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();

            clipboard.setContents(selection, null);

            JOptionPane.showMessageDialog(
                    this,
                    "Decrypted password copied to clipboard.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to access the clipboard.",
                    "Copy Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String decrypt(String input) throws Exception {
        // AES-GCM: current encrypted records
        if (input.startsWith("AESGCM:")) {
            return PasswordCrypto.decrypt(input);
        }

        // Legacy Caesar cipher: old records
        int key = 3;
        StringBuilder decryptedText = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);

            if (currentChar >= 'A' && currentChar <= 'Z') {
                decryptedText.append(
                        (char) (((currentChar - 'A' - key + 26) % 26) + 'A'));
            } else if (currentChar >= 'a' && currentChar <= 'z') {
                decryptedText.append(
                        (char) (((currentChar - 'a' - key + 26) % 26) + 'a'));
            } else if (currentChar >= '0' && currentChar <= '9') {
                decryptedText.append(
                        (char) (((currentChar - '0' - key + 10) % 10) + '0'));
            } else {
                decryptedText.append(currentChar);
            }
        }

        return decryptedText.toString();
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(
                            info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(
                    EncryptPage.class.getName()).log(
                            java.util.logging.Level.SEVERE,
                            null,
                            ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new EncryptPage().setVisible(true);
        });
    }
}