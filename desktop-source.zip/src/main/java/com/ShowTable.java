package com;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class ShowTable extends JFrame {

    private static final String MASK = "••••••••••••";
    private static final int ENCRYPTED_VALUE_COLUMN = 3;
    private static final int ID_COLUMN = 4;
    private final String username;
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[] { "APPLICATION / WEBSITE", "USERNAME", "PASSWORD", "Encrypted value", "Record id" }, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);
    private final JTextField searchField = new JTextField(24);
    private final JLabel countLabel = new JLabel("Loading your vault...");
    private final JLabel emptyLabel = new JLabel("No saved passwords yet.", SwingConstants.CENTER);
    private final JPanel cardPanel = new JPanel(new CardLayout());
    private final JScrollPane tableScrollPane = new JScrollPane(table);
    private final JButton revealButton = new JButton("View selected");
    private final JButton copyButton = new JButton("Copy selected");
    private final JButton updateButton = new JButton("Update selected");
    private final JButton deleteButton = new JButton("Delete selected");

    public ShowTable() {
        this("");
    }

    public ShowTable(String username) {
        this.username = username == null ? "" : username.trim();
        initialize();
        loadPasswords();
        setLocationRelativeTo(null);
    }

    private void initialize() {
        setTitle("Your Password Vault");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(760, 540));
        setPreferredSize(new Dimension(980, 660));

        JPanel root = new JPanel(new BorderLayout(0, 20));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(28, 34, 24, 34));

        JPanel header = new JPanel(new BorderLayout(16, 12));
        header.setOpaque(false);

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("Your password vault");
        title.setFont(Theme.TITLE_FONT);
        title.setForeground(Theme.TEXT);
        JLabel subtitle = new JLabel("Search your saved accounts. Passwords stay hidden until you ask to view them.");
        subtitle.setFont(Theme.BODY_FONT);
        subtitle.setForeground(Theme.MUTED);
        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(6));
        titlePanel.add(subtitle);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchPanel.setOpaque(false);
        Theme.styleTextField(searchField);
        searchField.setToolTipText("Search by app, website, or username");
        searchPanel.add(searchField);
        JButton clearButton = new JButton("Clear");
        Theme.styleSecondaryButton(clearButton);
        clearButton.addActionListener(event -> searchField.setText(""));
        searchPanel.add(clearButton);
        countLabel.setFont(Theme.BODY_FONT);
        countLabel.setForeground(Theme.MUTED);
        searchPanel.add(countLabel);

        header.add(titlePanel, BorderLayout.NORTH);
        header.add(searchPanel, BorderLayout.SOUTH);

        cardPanel.setBackground(Theme.CARD);
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(1, 1, 1, 1)));

        table.setFont(Theme.BODY_FONT);
        table.setRowHeight(42);
        table.setBackground(Theme.CARD);
        table.setForeground(Theme.TEXT);
        table.setSelectionBackground(Theme.PRIMARY);
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(Theme.BORDER);
        table.setShowVerticalLines(false);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(false);
        table.getTableHeader().setFont(Theme.BUTTON_FONT);
        table.getTableHeader().setBackground(Theme.SIDEBAR);
        table.getTableHeader().setForeground(Theme.TEXT);
        table.getTableHeader().setOpaque(true);
        table.getTableHeader().setReorderingAllowed(false);
        table.getColumnModel().getColumn(2).setCellRenderer((source, value, selected,
                focused, row, column) -> {
                    JLabel cell = new JLabel(MASK);
                    cell.setOpaque(true);
                    cell.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                    cell.setForeground(selected ? Color.WHITE : Theme.MUTED);
                    cell.setBackground(selected ? Theme.PRIMARY : Theme.CARD);
                    cell.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                    return cell;
                });
        table.removeColumn(table.getColumnModel().getColumn(ID_COLUMN));
        table.removeColumn(table.getColumnModel().getColumn(ENCRYPTED_VALUE_COLUMN));

        tableScrollPane.setBorder(BorderFactory.createEmptyBorder());
        tableScrollPane.getViewport().setBackground(Theme.CARD);
        cardPanel.add(tableScrollPane, "table");

        JPanel emptyPanel = new JPanel(new BorderLayout());
        emptyPanel.setBackground(Theme.CARD);
        emptyLabel.setFont(Theme.HEADING_FONT);
        emptyLabel.setForeground(Theme.MUTED);
        emptyPanel.add(emptyLabel, BorderLayout.CENTER);
        cardPanel.add(emptyPanel, "empty");

        JPanel footer = new JPanel(new BorderLayout(12, 0));
        footer.setOpaque(false);
        JLabel hint = new JLabel("Select an account to view or copy its password.");
        hint.setFont(Theme.BODY_FONT);
        hint.setForeground(Theme.MUTED);
        footer.add(hint, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actions.setOpaque(false);
        revealButton.setEnabled(false);
        copyButton.setEnabled(false);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
        Theme.styleButton(revealButton);
        Theme.styleSecondaryButton(copyButton);
        Theme.styleSecondaryButton(updateButton);
        Theme.styleSecondaryButton(deleteButton);
        JButton backButton = new JButton("Back");
        Theme.styleSecondaryButton(backButton);
        revealButton.addActionListener(event -> viewSelectedPassword());
        copyButton.addActionListener(event -> copySelectedPassword());
        updateButton.addActionListener(event -> updateSelectedPassword());
        deleteButton.addActionListener(event -> deleteSelectedPassword());
        backButton.addActionListener(event -> dispose());
        actions.add(revealButton);
        actions.add(copyButton);
        actions.add(updateButton);
        actions.add(deleteButton);
        actions.add(backButton);
        footer.add(actions, BorderLayout.EAST);

        root.add(header, BorderLayout.NORTH);
        root.add(cardPanel, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                String query = searchField.getText().trim();
                if (query.isEmpty()) {
                    return true;
                }
                String pattern = "(?i).*" + Pattern.quote(query) + ".*";
                return entry.getStringValue(0).matches(pattern)
                        || entry.getStringValue(1).matches(pattern);
            }
        });
        table.setRowSorter(sorter);

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent event) {
                updateCount();
            }

            @Override
            public void removeUpdate(DocumentEvent event) {
                updateCount();
            }

            @Override
            public void changedUpdate(DocumentEvent event) {
                updateCount();
            }
        });
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                updateSelectionActions();
            }
        });
        updateCount();
        pack();
    }

    private void loadPasswords() {
        if (username.isEmpty()) {
            countLabel.setText("Sign in to view your vault");
            revealButton.setEnabled(false);
            copyButton.setEnabled(false);
            return;
        }

        String sql = "SELECT srno, APPLICATION, USERNAME, ENCRYPTED_PASSWORD "
                + "FROM idusnewjava WHERE LoginUsername = ? ORDER BY APPLICATION";
        try (Connection connection = Connectionprovider.getCon();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    model.addRow(new Object[] {
                        results.getString("APPLICATION"),
                        results.getString("USERNAME"),
                        MASK,
                        results.getString("ENCRYPTED_PASSWORD"),
                        results.getLong("srno")
                    });
                }
            }
            emptyLabel.setText(model.getRowCount() == 0
                    ? "Your vault is empty. Add your first account to get started."
                    : "No accounts match this search.");
            updateCount();
        } catch (Exception exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Could not load saved passwords. Check your database connection and try again.",
                    "Vault unavailable",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            java.util.logging.Logger.getLogger(ShowTable.class.getName())
                    .log(java.util.logging.Level.SEVERE, "Could not load saved passwords", exception);
            dispose();
        }
    }

    private void updateCount() {
        int visible = table.getRowCount();
        int total = model.getRowCount();
        countLabel.setText(visible == total
                ? total + (total == 1 ? " saved account" : " saved accounts")
                : visible + " of " + total + " accounts");
        if (visible == 0) {
            emptyLabel.setText(total == 0
                    ? "Your vault is empty. Add your first account to get started."
                    : "No accounts match this search.");
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "empty");
        } else {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "table");
        }
        updateSelectionActions();
    }

    private void updateSelectionActions() {
        boolean selected = table.getSelectedRow() >= 0;
        revealButton.setEnabled(selected);
        copyButton.setEnabled(selected);
        updateButton.setEnabled(selected);
        deleteButton.setEnabled(selected);
    }

    private int selectedModelRow() {
        int selectedRow = table.getSelectedRow();
        return selectedRow < 0 ? -1 : table.convertRowIndexToModel(selectedRow);
    }

    private String selectedEncryptedPassword() {
        int modelRow = selectedModelRow();
        if (modelRow < 0) {
            return null;
        }
        Object encrypted = model.getValueAt(modelRow, ENCRYPTED_VALUE_COLUMN);
        return encrypted instanceof String ? (String) encrypted : null;
    }

    private void updateSelectedPassword() {
        int modelRow = selectedModelRow();
        if (modelRow < 0) {
            return;
        }

        final String decryptedPassword;
        try {
            decryptedPassword = PasswordCrypto.decrypt(
                    (String) model.getValueAt(modelRow, ENCRYPTED_VALUE_COLUMN));
        } catch (Exception exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Could not decrypt this saved password. Check your encryption key.",
                    "Unable to update password",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            java.util.logging.Logger.getLogger(ShowTable.class.getName())
                    .log(java.util.logging.Level.SEVERE, "Could not decrypt saved password for update", exception);
            return;
        }

        JDialog dialog = new JDialog(this, "Update saved password", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setResizable(false);

        JPanel content = new JPanel();
        content.setBackground(Theme.BACKGROUND);
        content.setBorder(BorderFactory.createEmptyBorder(22, 24, 20, 24));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        JTextField applicationField = new JTextField((String) model.getValueAt(modelRow, 0), 28);
        JTextField usernameField = new JTextField((String) model.getValueAt(modelRow, 1), 28);
        javax.swing.JPasswordField passwordField = new javax.swing.JPasswordField(decryptedPassword, 28);
        Theme.styleTextField(applicationField);
        Theme.styleTextField(usernameField);
        Theme.stylePasswordField(passwordField);
        applicationField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        addEditField(content, "Application / website", applicationField);
        content.add(Box.createVerticalStrut(12));
        addEditField(content, "Username", usernameField);
        content.add(Box.createVerticalStrut(12));
        addEditField(content, "Password", passwordField);
        content.add(Box.createVerticalStrut(18));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        JButton saveButton = new JButton("Save changes");
        JButton cancelButton = new JButton("Cancel");
        Theme.styleButton(saveButton);
        Theme.styleSecondaryButton(cancelButton);
        saveButton.addActionListener(event -> {
            String application = applicationField.getText().trim();
            String accountUsername = usernameField.getText().trim();
            char[] password = passwordField.getPassword();
            if (application.isEmpty() || accountUsername.isEmpty() || password.length == 0) {
                Arrays.fill(password, '\0');
                javax.swing.JOptionPane.showMessageDialog(
                        dialog,
                        "Application, username, and password are required.",
                        "Missing information",
                        javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (saveUpdatedPassword(modelRow, application, accountUsername, password)) {
                dialog.dispose();
            }
        });
        cancelButton.addActionListener(event -> dialog.dispose());
        actions.add(saveButton);
        actions.add(cancelButton);
        content.add(actions);

        dialog.setContentPane(content);
        dialog.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent event) {
                passwordField.setText("");
            }
        });
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void addEditField(JPanel panel, String labelText, Component field) {
        JLabel label = new JLabel(labelText);
        label.setFont(Theme.BODY_FONT);
        label.setForeground(Theme.TEXT);
        label.setAlignmentX(LEFT_ALIGNMENT);
        field.setFont(Theme.BODY_FONT);
        if (field instanceof javax.swing.JComponent) {
            ((javax.swing.JComponent) field).setAlignmentX(LEFT_ALIGNMENT);
        }
        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        panel.add(field);
    }

    private boolean saveUpdatedPassword(int modelRow, String application, String accountUsername, char[] password) {
        try {
            String encrypted = PasswordCrypto.encrypt(new String(password));
            Object recordId = model.getValueAt(modelRow, ID_COLUMN);
            String sql = "UPDATE idusnewjava SET APPLICATION = ?, USERNAME = ?, ENCRYPTED_PASSWORD = ? "
                    + "WHERE srno = ? AND LoginUsername = ?";
            try (Connection connection = Connectionprovider.getCon();
                    PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, application);
                statement.setString(2, accountUsername);
                statement.setString(3, encrypted);
                statement.setLong(4, ((Number) recordId).longValue());
                statement.setString(5, username);
                if (statement.executeUpdate() != 1) {
                    javax.swing.JOptionPane.showMessageDialog(
                            this,
                            "This saved password was not updated. Refresh the vault and try again.",
                            "Update not completed",
                            javax.swing.JOptionPane.WARNING_MESSAGE);
                    return false;
                }
            }

            model.setValueAt(application, modelRow, 0);
            model.setValueAt(accountUsername, modelRow, 1);
            model.setValueAt(MASK, modelRow, 2);
            model.setValueAt(encrypted, modelRow, ENCRYPTED_VALUE_COLUMN);
            updateCount();
            return true;
        } catch (Exception exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Could not update this saved password. Check your encryption key and database connection.",
                    "Update failed",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            java.util.logging.Logger.getLogger(ShowTable.class.getName())
                    .log(java.util.logging.Level.SEVERE, "Could not update saved password", exception);
            return false;
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    private void deleteSelectedPassword() {
        int modelRow = selectedModelRow();
        if (modelRow < 0) {
            return;
        }
        String application = (String) model.getValueAt(modelRow, 0);
        String accountUsername = (String) model.getValueAt(modelRow, 1);
        int answer = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "Permanently delete the saved password for " + accountUsername + " at " + application + "?",
                "Delete saved password",
                javax.swing.JOptionPane.YES_NO_OPTION,
                javax.swing.JOptionPane.WARNING_MESSAGE);
        if (answer != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM idusnewjava WHERE srno = ? AND LoginUsername = ?";
        try (Connection connection = Connectionprovider.getCon();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, ((Number) model.getValueAt(modelRow, ID_COLUMN)).longValue());
            statement.setString(2, username);
            if (statement.executeUpdate() != 1) {
                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "This saved password was not deleted. Refresh the vault and try again.",
                        "Delete not completed",
                        javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            model.removeRow(modelRow);
            updateCount();
        } catch (Exception exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Could not delete this saved password. Check your database connection.",
                    "Delete failed",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            java.util.logging.Logger.getLogger(ShowTable.class.getName())
                    .log(java.util.logging.Level.SEVERE, "Could not delete saved password", exception);
        }
    }

    private void viewSelectedPassword() {
        String encrypted = selectedEncryptedPassword();
        if (encrypted == null) {
            return;
        }

        try {
            showPasswordDialog(PasswordCrypto.decrypt(encrypted));
        } catch (Exception exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Could not decrypt this saved password. Check your encryption key.",
                    "Unable to view password",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            java.util.logging.Logger.getLogger(ShowTable.class.getName())
                    .log(java.util.logging.Level.SEVERE, "Could not decrypt saved password", exception);
        }
    }

    private void showPasswordDialog(String password) {
        char[] secret = password.toCharArray();
        JDialog dialog = new JDialog(this, "View saved password", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setMinimumSize(new Dimension(430, 190));
        dialog.setResizable(false);

        JPanel content = new JPanel(new BorderLayout(12, 18));
        content.setBackground(Theme.BACKGROUND);
        content.setBorder(BorderFactory.createEmptyBorder(22, 24, 20, 24));

        JPanel details = new JPanel();
        details.setOpaque(false);
        details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("Password revealed temporarily");
        title.setFont(Theme.HEADING_FONT);
        title.setForeground(Theme.TEXT);
        JLabel note = new JLabel("It will be hidden and cleared automatically in 20 seconds.");
        note.setFont(Theme.BODY_FONT);
        note.setForeground(Theme.MUTED);
        details.add(title);
        details.add(Box.createVerticalStrut(6));
        details.add(note);

        javax.swing.JPasswordField passwordField = new javax.swing.JPasswordField();
        passwordField.setFont(Theme.BODY_FONT);
        passwordField.setEchoChar('\u2022');
        passwordField.setEditable(false);
        Theme.stylePasswordField(passwordField);
        passwordField.setEchoChar('\u2022');
        passwordField.setText(password);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        JButton reveal = new JButton("Show");
        JButton copy = new JButton("Copy");
        JButton close = new JButton("Close");
        Theme.styleSecondaryButton(reveal);
        Theme.styleSecondaryButton(copy);
        Theme.styleButton(close);

        Timer[] hideTimer = new Timer[1];
        Timer clearTimer = new Timer(20000, event -> dialog.dispose());
        clearTimer.setRepeats(false);
        reveal.addActionListener(event -> {
            if (passwordField.getEchoChar() == 0) {
                passwordField.setEchoChar('\u2022');
                reveal.setText("Show");
                if (hideTimer[0] != null) {
                    hideTimer[0].stop();
                }
            } else {
                passwordField.setEchoChar((char) 0);
                reveal.setText("Hide");
                if (hideTimer[0] != null) {
                    hideTimer[0].stop();
                }
                hideTimer[0] = new Timer(10000, hideEvent -> {
                    passwordField.setEchoChar('\u2022');
                    reveal.setText("Show");
                });
                hideTimer[0].setRepeats(false);
                hideTimer[0].start();
            }
        });
        copy.addActionListener(event -> copyPasswordTemporarily(secret, dialog));
        close.addActionListener(event -> dialog.dispose());
        actions.add(reveal);
        actions.add(copy);
        actions.add(close);

        content.add(details, BorderLayout.NORTH);
        content.add(passwordField, BorderLayout.CENTER);
        content.add(actions, BorderLayout.SOUTH);
        dialog.setContentPane(content);
        dialog.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent event) {
                Arrays.fill(secret, '\0');
                passwordField.setText("");
                clearTimer.stop();
                if (hideTimer[0] != null) {
                    hideTimer[0].stop();
                }
            }
        });
        clearTimer.start();
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void copySelectedPassword() {
        String encrypted = selectedEncryptedPassword();
        if (encrypted == null) {
            return;
        }
        try {
            char[] password = PasswordCrypto.decrypt(encrypted).toCharArray();
            try {
                copyPasswordTemporarily(password, this);
            } finally {
                Arrays.fill(password, '\0');
            }
        } catch (Exception exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Could not decrypt this saved password. Check your encryption key.",
                    "Unable to copy password",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            java.util.logging.Logger.getLogger(ShowTable.class.getName())
                    .log(java.util.logging.Level.SEVERE, "Could not copy saved password", exception);
        }
    }

    private void copyPasswordTemporarily(char[] password, Component parent) {
        try {
            String copied = new String(password);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(new StringSelection(copied), null);
            Timer clearClipboard = new Timer(30000, event -> {
                try {
                    Transferable current = clipboard.getContents(null);
                    if (current != null && current.isDataFlavorSupported(DataFlavor.stringFlavor)
                            && copied.equals(current.getTransferData(DataFlavor.stringFlavor))) {
                        clipboard.setContents(new StringSelection(""), null);
                    }
                } catch (IllegalStateException | IOException | UnsupportedFlavorException exception) {
                    java.util.logging.Logger.getLogger(ShowTable.class.getName())
                            .log(java.util.logging.Level.WARNING, "Could not clear password clipboard", exception);
                }
            });
            clearClipboard.setRepeats(false);
            clearClipboard.start();
            javax.swing.JOptionPane.showMessageDialog(
                    parent,
                    "Copied. The clipboard will be cleared after 30 seconds if unchanged.",
                    "Password copied",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } catch (IllegalStateException exception) {
            javax.swing.JOptionPane.showMessageDialog(
                    parent,
                    "The clipboard is unavailable. Try again.",
                    "Copy failed",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new ShowTable().setVisible(true));
    }
}
