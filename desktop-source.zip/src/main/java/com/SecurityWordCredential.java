package com;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import org.mindrot.jbcrypt.BCrypt;

public final class SecurityWordCredential {

    private SecurityWordCredential() {
    }

    public static String hash(char[] securityWord) {
        String normalized = normalize(securityWord);
        if (normalized.isEmpty()) {
            throw new IllegalArgumentException("Security word cannot be blank.");
        }
        return BCrypt.hashpw(normalized, BCrypt.gensalt(12));
    }

    public static boolean verify(char[] candidate, String storedCredential) {
        if (candidate == null || storedCredential == null) {
            return false;
        }

        String normalized = normalize(candidate);
        if (normalized.isEmpty()) {
            return false;
        }

        if (isHashed(storedCredential)) {
            return BCrypt.checkpw(normalized, storedCredential);
        }

        byte[] candidateBytes = normalized.getBytes(StandardCharsets.UTF_8);
        byte[] storedBytes = storedCredential.trim().getBytes(StandardCharsets.UTF_8);
        try {
            return MessageDigest.isEqual(candidateBytes, storedBytes);
        } finally {
            Arrays.fill(candidateBytes, (byte) 0);
            Arrays.fill(storedBytes, (byte) 0);
        }
    }

    public static boolean isHashed(String credential) {
        return credential != null
                && (credential.startsWith("$2a$")
                || credential.startsWith("$2b$")
                || credential.startsWith("$2y$"));
    }

    private static String normalize(char[] securityWord) {
        return securityWord == null ? "" : new String(securityWord).trim();
    }
}
