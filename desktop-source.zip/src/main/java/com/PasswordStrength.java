package com;

public final class PasswordStrength {

    private PasswordStrength() {
    }

    public static Result evaluate(String password) {
        if (password == null || password.isEmpty()) {
            return new Result(0, Level.VERY_WEAK);
        }

        int score = 0;
        if (password.codePointCount(0, password.length()) >= 12) {
            score++;
        }
        if (password.codePoints().anyMatch(Character::isUpperCase)) {
            score++;
        }
        if (password.codePoints().anyMatch(Character::isLowerCase)) {
            score++;
        }
        if (password.codePoints().anyMatch(Character::isDigit)) {
            score++;
        }
        if (password.codePoints().anyMatch(character -> !Character.isLetterOrDigit(character))) {
            score++;
        }

        return new Result(score, Level.fromScore(score));
    }

    public enum Level {
        VERY_WEAK("Very Weak"),
        WEAK("Weak"),
        MEDIUM("Medium"),
        STRONG("Strong"),
        VERY_STRONG("Very Strong");

        private final String displayName;

        Level(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }

        private static Level fromScore(int score) {
            switch (score) {
                case 2:
                    return WEAK;
                case 3:
                    return MEDIUM;
                case 4:
                    return STRONG;
                case 5:
                    return VERY_STRONG;
                default:
                    return VERY_WEAK;
            }
        }
    }

    public static final class Result {
        private final int score;
        private final Level level;

        private Result(int score, Level level) {
            this.score = score;
            this.level = level;
        }

        public int getScore() {
            return score;
        }

        public Level getLevel() {
            return level;
        }
    }
}
