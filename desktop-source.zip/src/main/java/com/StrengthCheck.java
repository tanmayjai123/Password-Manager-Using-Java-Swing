package com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;

public class StrengthCheck extends JFrame {

    private final JPasswordField passwordField = new JPasswordField();
    private final JLabel resultLabel = new JLabel("Enter a password to check its strength.");
    private final JProgressBar strengthMeter = new JProgressBar(0, 5);
    private final JCheckBox showPassword = new JCheckBox("Show password");
    private final char passwordEchoChar = passwordField.getEchoChar();

    public StrengthCheck() {
        initialize();
    }

    private void initialize() {
        setTitle("Password strength");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(560, 410));
        setPreferredSize(new Dimension(680, 470));

        JPanel root = new JPanel(new BorderLayout(0, 24));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(30, 38, 28, 38));

        JPanel heading = new JPanel(new BorderLayout(0, 7));
        heading.setOpaque(false);
        JLabel title = new JLabel("Password strength");
        title.setFont(Theme.TITLE_FONT);
        title.setForeground(Theme.TEXT);
        JLabel subtitle = new JLabel("Check your password locally. It is not sent or saved.");
        subtitle.setFont(Theme.BODY_FONT);
        subtitle.setForeground(Theme.MUTED);
        heading.add(title, BorderLayout.NORTH);
        heading.add(subtitle, BorderLayout.SOUTH);

        JPanel card = new JPanel();
        card.setOpaque(true);
        card.setBackground(Theme.CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(22, 24, 22, 24)));
        card.setLayout(new javax.swing.BoxLayout(card, javax.swing.BoxLayout.Y_AXIS));

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(Theme.BODY_FONT);
        passwordLabel.setForeground(Theme.TEXT);
        passwordLabel.setAlignmentX(LEFT_ALIGNMENT);

        Theme.stylePasswordField(passwordField);
        passwordField.setPreferredSize(new Dimension(400, 46));
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        passwordField.setAlignmentX(LEFT_ALIGNMENT);
        passwordField.setToolTipText("Type a password to evaluate it on this device");
        passwordField.getAccessibleContext().setAccessibleName("Password to check");
        passwordField.addActionListener(event -> checkStrength());

        showPassword.setOpaque(false);
        showPassword.setForeground(Theme.MUTED);
        showPassword.setFont(Theme.BODY_FONT);
        showPassword.setFocusPainted(false);
        showPassword.setAlignmentX(LEFT_ALIGNMENT);
        showPassword.addActionListener(event ->
                passwordField.setEchoChar(showPassword.isSelected() ? (char) 0 : passwordEchoChar));

        resultLabel.setFont(Theme.HEADING_FONT);
        resultLabel.setForeground(Theme.MUTED);
        resultLabel.setAlignmentX(LEFT_ALIGNMENT);

        strengthMeter.setStringPainted(true);
        strengthMeter.setString("Not checked");
        strengthMeter.setBackground(Theme.INPUT);
        strengthMeter.setForeground(Theme.MUTED);
        strengthMeter.setBorderPainted(false);
        strengthMeter.setPreferredSize(new Dimension(100, 12));
        strengthMeter.setMaximumSize(new Dimension(Integer.MAX_VALUE, 12));
        strengthMeter.setAlignmentX(LEFT_ALIGNMENT);
        strengthMeter.setVisible(false);

        JLabel guidance = new JLabel(
                "<html><b>For a stronger password</b><br>"
                + "Use 12 or more characters with a mix of uppercase and lowercase letters, "
                + "numbers, and symbols.</html>");
        guidance.setFont(Theme.BODY_FONT);
        guidance.setForeground(Theme.MUTED);
        guidance.setAlignmentX(LEFT_ALIGNMENT);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(LEFT_ALIGNMENT);
        JButton checkButton = new JButton("Check strength");
        Theme.styleButton(checkButton);
        checkButton.addActionListener(event -> checkStrength());
        JButton clearButton = new JButton("Clear");
        Theme.styleSecondaryButton(clearButton);
        clearButton.addActionListener(event -> clear());
        buttons.add(checkButton);
        buttons.add(clearButton);

        card.add(passwordLabel);
        card.add(javax.swing.Box.createVerticalStrut(8));
        card.add(passwordField);
        card.add(javax.swing.Box.createVerticalStrut(4));
        card.add(showPassword);
        card.add(javax.swing.Box.createVerticalStrut(18));
        card.add(resultLabel);
        card.add(javax.swing.Box.createVerticalStrut(10));
        card.add(strengthMeter);
        card.add(javax.swing.Box.createVerticalStrut(20));
        card.add(guidance);
        card.add(javax.swing.Box.createVerticalStrut(22));
        card.add(buttons);

        JPanel footer = new JPanel(new GridLayout(1, 1));
        footer.setOpaque(false);
        JLabel privacy = new JLabel("Evaluation happens only in this window.", SwingConstants.CENTER);
        privacy.setForeground(Theme.MUTED);
        privacy.setFont(Theme.BODY_FONT);
        footer.add(privacy);

        root.add(heading, BorderLayout.NORTH);
        root.add(card, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
        getRootPane().setDefaultButton(checkButton);
        pack();
        setLocationRelativeTo(null);
    }

    private void checkStrength() {
        PasswordStrength.Result result = PasswordStrength.evaluate(
                new String(passwordField.getPassword()));
        PasswordStrength.Level level = result.getLevel();
        resultLabel.setText("Strength: " + level.getDisplayName());
        resultLabel.setForeground(colorFor(level));
        strengthMeter.setValue(result.getScore());
        strengthMeter.setString(level.getDisplayName());
        strengthMeter.setForeground(colorFor(level));
        strengthMeter.setVisible(true);
    }

    private Color colorFor(PasswordStrength.Level level) {
        switch (level) {
            case VERY_WEAK:
            case WEAK:
                return Theme.DANGER;
            case MEDIUM:
                return new Color(250, 204, 21);
            case STRONG:
            case VERY_STRONG:
                return Theme.SUCCESS;
            default:
                throw new IllegalStateException("Unsupported password strength: " + level);
        }
    }

    private void clear() {
        passwordField.setText("");
        resultLabel.setText("Enter a password to check its strength.");
        resultLabel.setForeground(Theme.MUTED);
        strengthMeter.setValue(0);
        strengthMeter.setString("Not checked");
        strengthMeter.setForeground(Theme.MUTED);
        strengthMeter.setVisible(false);
        showPassword.setSelected(false);
        passwordField.setEchoChar(passwordEchoChar);
        passwordField.requestFocusInWindow();
    }
}
