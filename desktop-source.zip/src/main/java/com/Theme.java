
package com;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public final class Theme {

    private Theme() {
        // Utility class; do not create objects.
    }

    // Premium dark palette
    public static final Color BACKGROUND = new Color(11, 15, 25);
    public static final Color SIDEBAR = new Color(15, 23, 42);
    public static final Color CARD = new Color(23, 32, 51);
    public static final Color INPUT = new Color(30, 41, 59);

    public static final Color PRIMARY = new Color(59, 130, 246);
    public static final Color PRIMARY_HOVER = new Color(37, 99, 235);

    public static final Color TEXT = new Color(241, 245, 249);
    public static final Color MUTED = new Color(148, 163, 184);
    public static final Color BORDER = new Color(51, 65, 85);
    public static final Color SUCCESS = new Color(34, 197, 94);
    public static final Color DANGER = new Color(248, 113, 113);

    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 26);

    public static final Font HEADING_FONT = new Font("Segoe UI", Font.BOLD, 18);

    public static final Font BODY_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public static void styleButton(JButton button) {
        button.setFont(BUTTON_FONT);
        button.setBackground(PRIMARY);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(
                new EmptyBorder(11, 18, 11, 18));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (button.isEnabled()) {
                    button.setBackground(PRIMARY_HOVER);
                }
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(PRIMARY);
            }
        });
    }

    public static void styleSecondaryButton(JButton button) {
        button.setFont(BUTTON_FONT);
        button.setBackground(CARD);
        button.setForeground(TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        new EmptyBorder(10, 16, 10, 16)));
    }

    public static void styleTextField(JTextField field) {
        field.setFont(BODY_FONT);
        field.setForeground(TEXT);
        field.setBackground(INPUT);
        field.setCaretColor(TEXT);
        field.setSelectionColor(PRIMARY);
        field.setSelectedTextColor(Color.WHITE);
        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        new EmptyBorder(10, 12, 10, 12)));
    }

    public static void stylePasswordField(JPasswordField field) {
        styleTextField(field);
    }
}
