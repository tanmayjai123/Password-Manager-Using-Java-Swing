package com;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class PasswordGenerator {

    private static final String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    private static final String DIGITS = "0123456789";
    private static final String SYMBOLS = "!@#$%^&*().[];:~";

    private PasswordGenerator() {
    }

    public static String generate(
            int length,
            boolean includeUppercase,
            boolean includeLowercase,
            boolean includeDigits,
            boolean includeSymbols) {
        if (length < 1 || length > 256) {
            throw new IllegalArgumentException("Length must be between 1 and 256.");
        }

        List<String> selectedGroups = new ArrayList<>();
        if (includeUppercase) {
            selectedGroups.add(UPPERCASE);
        }
        if (includeLowercase) {
            selectedGroups.add(LOWERCASE);
        }
        if (includeDigits) {
            selectedGroups.add(DIGITS);
        }
        if (includeSymbols) {
            selectedGroups.add(SYMBOLS);
        }
        if (selectedGroups.isEmpty()) {
            throw new IllegalArgumentException("Select at least one character type.");
        }
        if (length < selectedGroups.size()) {
            throw new IllegalArgumentException(
                    "Length must be at least the number of selected character types.");
        }

        StringBuilder alphabet = new StringBuilder();
        for (String group : selectedGroups) {
            alphabet.append(group);
        }

        SecureRandom random = new SecureRandom();
        List<Character> password = new ArrayList<>(length);
        for (String group : selectedGroups) {
            password.add(group.charAt(random.nextInt(group.length())));
        }
        while (password.size() < length) {
            password.add(alphabet.charAt(random.nextInt(alphabet.length())));
        }
        Collections.shuffle(password, random);

        StringBuilder result = new StringBuilder(length);
        for (char character : password) {
            result.append(character);
        }
        return result.toString();
    }
}
