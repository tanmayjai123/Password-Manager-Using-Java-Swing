
package com;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import javax.swing.JOptionPane;

public class GeneratePass extends javax.swing.JFrame {

    public GeneratePass() {
        initComponents();
        applyDarkTheme();
        setLocationRelativeTo(null);
    }

    private void applyDarkTheme() {
        getContentPane().setBackground(Theme.BACKGROUND);

        // Header
        jPanel1.setBackground(Theme.SIDEBAR);
        jLabel3.setForeground(Theme.TEXT);
        jLabel3.setFont(Theme.TITLE_FONT);

        // Remove old hard-coded background image
        jLabel4.setIcon(null);
        jLabel4.setText("");
        jLabel4.setOpaque(true);
        jLabel4.setBackground(Theme.BACKGROUND);

        // Character options
        Capital.setBackground(Theme.BACKGROUND);
        Capital.setForeground(Theme.TEXT);
        Capital.setFont(Theme.BODY_FONT);
        Capital.setFocusPainted(false);
        Capital.setOpaque(true);

        Small.setBackground(Theme.BACKGROUND);
        Small.setForeground(Theme.TEXT);
        Small.setFont(Theme.BODY_FONT);
        Small.setFocusPainted(false);
        Small.setOpaque(true);

        Numbers.setBackground(Theme.BACKGROUND);
        Numbers.setForeground(Theme.TEXT);
        Numbers.setFont(Theme.BODY_FONT);
        Numbers.setFocusPainted(false);
        Numbers.setOpaque(true);

        Symbols.setBackground(Theme.BACKGROUND);
        Symbols.setForeground(Theme.TEXT);
        Symbols.setFont(Theme.BODY_FONT);
        Symbols.setFocusPainted(false);
        Symbols.setOpaque(true);

        // Generated password
        jLabel1.setForeground(Theme.TEXT);
        jLabel1.setFont(Theme.HEADING_FONT);
        Theme.styleTextField(jTextField1);

        // Buttons
        Theme.styleButton(jButton1);
        Theme.styleButton(jButton4);
        Theme.styleSecondaryButton(jButton2);

        setTitle("Password Generator");
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        Capital = new javax.swing.JCheckBox();
        Small = new javax.swing.JCheckBox();
        Numbers = new javax.swing.JCheckBox();
        jButton2 = new javax.swing.JButton();
        Symbols = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(
                new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 102, 0));
        jPanel1.setLayout(
                new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(
                new java.awt.Font("Franklin Gothic Medium Cond", 1, 36));
        jLabel3.setText("SELECT REQUIREMENTS");

        jPanel1.add(
                jLabel3,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 500, 35));

        getContentPane().add(
                jPanel1,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 680, 60));

        Capital.setFont(
                new java.awt.Font("Franklin Gothic Medium Cond", 1, 18));
        Capital.setText("CAPITAL LETTERS");
        Capital.setFocusable(false);
        Capital.setPreferredSize(new java.awt.Dimension(180, 40));

        getContentPane().add(
                Capital,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 200, 30));

        Small.setFont(
                new java.awt.Font("Franklin Gothic Medium Cond", 1, 18));
        Small.setText("SMALL LETTERS");

        getContentPane().add(
                Small,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 200, 30));

        Numbers.setFont(
                new java.awt.Font("Franklin Gothic Medium Cond", 1, 18));
        Numbers.setText("NUMBERS");

        getContentPane().add(
                Numbers,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 200, 30));

        Symbols.setFont(
                new java.awt.Font("Franklin Gothic Medium Cond", 1, 18));
        Symbols.setText("SYMBOLS");

        getContentPane().add(
                Symbols,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 200, 30));

        jButton2.setText("BACK");
        jButton2.addActionListener(evt -> jButton2ActionPerformed(evt));

        getContentPane().add(
                jButton2,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 110, 40));

        jLabel1.setFont(
                new java.awt.Font("Franklin Gothic Heavy", 1, 24));
        jLabel1.setText("GENERATED PASSWORD");

        getContentPane().add(
                jLabel1,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 90, 320, 40));

        getContentPane().add(
                jTextField1,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 145, 300, 45));

        jButton4.setText("COPY");
        jButton4.addActionListener(evt -> jButton4ActionPerformed(evt));

        getContentPane().add(
                jButton4,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 205, 110, 40));

        jButton1.setText("GENERATE");
        jButton1.addActionListener(evt -> jButton1ActionPerformed(evt));

        getContentPane().add(
                jButton1,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 280, 120, 40));

        jLabel4.setOpaque(true);
        getContentPane().add(
                jLabel4,
                new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 680, 320));

        pack();
        setSize(700, 420);
        setResizable(false);
    }

    private void jButton1ActionPerformed(
            java.awt.event.ActionEvent evt) {

        String input = JOptionPane.showInputDialog(
                this,
                "Enter password length (1-256):");

        if (input == null) {
            return;
        }

        int length;

        try {
            length = Integer.parseInt(input.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid whole number.",
                    "Invalid Length",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (length < 1 || length > 256) {
            JOptionPane.showMessageDialog(
                    this,
                    "Password length must be between 1 and 256.",
                    "Invalid Length",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            jTextField1.setText(PasswordGenerator.generate(
                    length,
                    Capital.isSelected(),
                    Small.isSelected(),
                    Numbers.isSelected(),
                    Symbols.isSelected()));
        } catch (IllegalArgumentException exception) {
            JOptionPane.showMessageDialog(
                    this,
                    exception.getMessage(),
                    "Invalid Requirements",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void jButton4ActionPerformed(
            java.awt.event.ActionEvent evt) {

        String text = jTextField1.getText();

        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Generate a password before copying it.");
            return;
        }

        try {
            StringSelection selection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();

            clipboard.setContents(selection, null);

            JOptionPane.showMessageDialog(
                    this,
                    "Password copied to clipboard!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not access the clipboard.");
        }
    }

    private void jButton2ActionPerformed(
            java.awt.event.ActionEvent evt) {
        dispose();
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(GeneratePass.class.getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new GeneratePass().setVisible(true);
        });
    }

    private javax.swing.JCheckBox Capital;
    private javax.swing.JCheckBox Numbers;
    private javax.swing.JCheckBox Small;
    private javax.swing.JCheckBox Symbols;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
}
