import com.Theme;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.security.SecureRandom;
import javax.swing.*;
import com.AddPass1;
import com.Connectionprovider;
import com.WindowNavigation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.mindrot.jbcrypt.BCrypt;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tanmay Jaiswal
 */
public class LoginForm extends javax.swing.JFrame {

    private static final String CAPTCHA_CHARACTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom CAPTCHA_RANDOM = new SecureRandom();
    private Object JoptionPane;
    private final JLabel loginFeedback = new JLabel(" ");
    private final JLabel captchaLabel = new JLabel("", SwingConstants.CENTER);
    private final JTextField captchaResponse = new JTextField();
    private String captcha;

    /**
     * Creates new form LoginForm
     */
    public LoginForm() {
        initComponents();
        applyDarkTheme();
        this.setLocationRelativeTo(null);
    }

    private void applyDarkTheme() {
        setTitle("Password Manager | Sign in");
        setMinimumSize(new Dimension(480, 660));
        setPreferredSize(new Dimension(560, 720));
        setResizable(true);
        getContentPane().setBackground(Theme.BACKGROUND);

        jPanel1.setVisible(false);
        jPanel2.removeAll();
        jPanel2.setLayout(new BorderLayout());
        jPanel2.setBackground(Theme.SIDEBAR);
        jPanel2.setBorder(BorderFactory.createEmptyBorder(20, 28, 20, 28));
        jLabel1.setText("PASSWORD MANAGER");
        jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 13));
        jLabel1.setForeground(Theme.PRIMARY);
        jLabelClose.setVisible(false);
        jLabel3.setVisible(false);
        jPanel2.add(jLabel1, BorderLayout.WEST);

        jPanel3.removeAll();
        jPanel3.setLayout(new BoxLayout(jPanel3, BoxLayout.Y_AXIS));
        jPanel3.setBackground(Theme.CARD);
        jPanel3.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(30, 34, 28, 34)));

        JLabel welcome = new JLabel("Welcome back");
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 27));
        welcome.setForeground(Theme.TEXT);
        welcome.setAlignmentX(LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("Sign in to access your saved accounts.");
        subtitle.setFont(Theme.BODY_FONT);
        subtitle.setForeground(Theme.MUTED);
        subtitle.setAlignmentX(LEFT_ALIGNMENT);

        jLabel4.setText("Username");
        jLabel5.setText("Password");
        jLabel4.setFont(Theme.BODY_FONT);
        jLabel5.setFont(Theme.BODY_FONT);
        jLabel4.setForeground(Theme.TEXT);
        jLabel5.setForeground(Theme.TEXT);
        jLabel4.setAlignmentX(LEFT_ALIGNMENT);
        jLabel5.setAlignmentX(LEFT_ALIGNMENT);

        Theme.styleTextField(LoginUsername);
        Theme.stylePasswordField(jPasswordField1);
        Theme.styleTextField(captchaResponse);
        LoginUsername.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        jPasswordField1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        captchaResponse.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        LoginUsername.setToolTipText("Enter your account username");
        jPasswordField1.setToolTipText("Enter your master password");
        captchaResponse.setToolTipText("Enter the verification code shown");
        LoginUsername.getAccessibleContext().setAccessibleName("Username");
        jPasswordField1.getAccessibleContext().setAccessibleName("Master password");
        captchaResponse.getAccessibleContext().setAccessibleName("Verification code");
        LoginUsername.addActionListener(event -> jPasswordField1.requestFocusInWindow());
        jPasswordField1.addActionListener(event -> jButton1.doClick());
        captchaResponse.addActionListener(event -> jButton1.doClick());

        captchaLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        captchaLabel.setForeground(Theme.PRIMARY);
        captchaLabel.setBackground(Theme.INPUT);
        captchaLabel.setOpaque(true);
        captchaLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)));
        captchaLabel.setPreferredSize(new Dimension(132, 42));
        captchaLabel.getAccessibleContext().setAccessibleName("Login verification code");
        refreshCaptcha();

        JButton refreshCaptchaButton = new JButton("New code");
        Theme.styleSecondaryButton(refreshCaptchaButton);
        refreshCaptchaButton.setPreferredSize(new Dimension(112, 42));
        refreshCaptchaButton.setMaximumSize(new Dimension(112, 42));
        refreshCaptchaButton.addActionListener(event -> refreshCaptcha());
        JPanel captchaChallenge = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        captchaChallenge.setOpaque(false);
        captchaChallenge.setAlignmentX(LEFT_ALIGNMENT);
        captchaChallenge.add(captchaLabel);
        captchaChallenge.add(refreshCaptchaButton);
        JPanel captchaPanel = new JPanel();
        captchaPanel.setOpaque(false);
        captchaPanel.setLayout(new BoxLayout(captchaPanel, BoxLayout.Y_AXIS));
        captchaPanel.setAlignmentX(LEFT_ALIGNMENT);
        captchaResponse.setAlignmentX(LEFT_ALIGNMENT);
        captchaPanel.add(captchaChallenge);
        captchaPanel.add(Box.createVerticalStrut(8));
        captchaPanel.add(captchaResponse);
        captchaPanel.setPreferredSize(new Dimension(420, 92));
        captchaPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
        JLabel captchaDescription = new JLabel("Enter verification code");
        captchaDescription.setFont(Theme.BODY_FONT);
        captchaDescription.setForeground(Theme.TEXT);
        captchaDescription.setAlignmentX(LEFT_ALIGNMENT);

        jCheckBox1.setText("Show password");
        jCheckBox1.setOpaque(false);
        jCheckBox1.setForeground(Theme.MUTED);
        jCheckBox1.setFocusPainted(false);

        loginFeedback.setFont(Theme.BODY_FONT);
        loginFeedback.setForeground(Theme.DANGER);
        loginFeedback.setAlignmentX(LEFT_ALIGNMENT);

        Theme.styleButton(jButton1);
        Theme.styleSecondaryButton(jButton2);
        jButton1.setText("Sign in");
        jButton2.setText("Cancel");
        jButton1.setPreferredSize(new Dimension(150, 46));
        jButton2.setPreferredSize(new Dimension(120, 46));
        jLabelRegister.setText("Create a new account");
        jLabelRegister.setFont(Theme.BODY_FONT);
        jLabelRegister.setForeground(Theme.PRIMARY);
        jLabelRegister.setAlignmentX(LEFT_ALIGNMENT);
        jLabelRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelRegister.getAccessibleContext().setAccessibleName("Create a new account");

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actions.setOpaque(false);
        actions.setAlignmentX(LEFT_ALIGNMENT);
        actions.add(jButton1);
        actions.add(jButton2);

        jPanel3.add(welcome);
        jPanel3.add(Box.createVerticalStrut(6));
        jPanel3.add(subtitle);
        jPanel3.add(Box.createVerticalStrut(20));
        jPanel3.add(jLabel4);
        jPanel3.add(Box.createVerticalStrut(8));
        jPanel3.add(LoginUsername);
        jPanel3.add(Box.createVerticalStrut(14));
        jPanel3.add(jLabel5);
        jPanel3.add(Box.createVerticalStrut(8));
        jPanel3.add(jPasswordField1);
        jPanel3.add(Box.createVerticalStrut(5));
        jPanel3.add(jCheckBox1);
        jPanel3.add(Box.createVerticalStrut(10));
        jPanel3.add(captchaDescription);
        jPanel3.add(Box.createVerticalStrut(6));
        jPanel3.add(captchaPanel);
        jPanel3.add(Box.createVerticalStrut(8));
        jPanel3.add(loginFeedback);
        jPanel3.add(Box.createVerticalStrut(12));
        jPanel3.add(actions);
        jPanel3.add(Box.createVerticalStrut(14));
        jPanel3.add(jLabelRegister);

        JPanel root = new JPanel(new BorderLayout(0, 28));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(22, 28, 28, 28));
        root.add(jPanel2, BorderLayout.NORTH);
        root.add(jPanel3, BorderLayout.CENTER);
        setContentPane(root);

        getRootPane().setDefaultButton(jButton1);
        setBackground(Theme.BACKGROUND);
        pack();
        setLocationRelativeTo(null);

        SwingUtilities.invokeLater(() -> LoginUsername.requestFocusInWindow());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated
    // Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabelClose = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        LoginUsername = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabelRegister = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE));
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(false);

        jPanel2.setBackground(new java.awt.Color(0, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Login Form");

        jLabelClose.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabelClose.setText("X");
        jLabelClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCloseMouseClicked(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("-");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(jLabelClose)
                                .addGap(27, 27, 27)));
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel1)
                                        .addComponent(jLabelClose)
                                        .addComponent(jLabel3))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

        jPanel3.setBackground(new java.awt.Color(7, 7, 36));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Username:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Password:");

        LoginUsername.setBackground(new java.awt.Color(108, 122, 137));
        LoginUsername.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LoginUsername.setForeground(new java.awt.Color(228, 241, 254));
        LoginUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginUsernameActionPerformed(evt);
            }
        });

        jPasswordField1.setBackground(new java.awt.Color(108, 122, 137));
        jPasswordField1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPasswordField1.setForeground(new java.awt.Color(228, 241, 254));
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(0, 255, 255));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Login");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 255, 255));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabelRegister.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelRegister.setForeground(new java.awt.Color(255, 255, 255));
        jLabelRegister.setText("Click here to Create A New Account");
        jLabelRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelRegister.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelRegisterMouseClicked(evt);
            }
        });

        jCheckBox1.setBackground(new java.awt.Color(0, 0, 0));
        jCheckBox1.setForeground(new java.awt.Color(0, 204, 204));
        jCheckBox1.setText("Show Pass");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGroup(jPanel3Layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                                .addComponent(jButton2,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE, 90,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(jButton1,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE, 90,
                                                                        javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                                .addGroup(jPanel3Layout.createParallelGroup(
                                                                        javax.swing.GroupLayout.Alignment.LEADING,
                                                                        false)
                                                                        .addComponent(jLabel5,
                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                Short.MAX_VALUE)
                                                                        .addComponent(jLabel4,
                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                130, Short.MAX_VALUE))
                                                                .addPreferredGap(
                                                                        javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(jPanel3Layout.createParallelGroup(
                                                                        javax.swing.GroupLayout.Alignment.LEADING,
                                                                        false)
                                                                        .addComponent(LoginUsername,
                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                180, Short.MAX_VALUE)
                                                                        .addComponent(jPasswordField1))))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19,
                                                        Short.MAX_VALUE)
                                                .addComponent(jCheckBox1))
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(116, 116, 116)
                                                .addComponent(jLabelRegister, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                        215, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap()));
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel4)
                                        .addComponent(LoginUsername, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel5)
                                        .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jCheckBox1))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 35,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jLabelRegister)
                                .addContainerGap(40, Short.MAX_VALUE)));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(0, 0, 0)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }// GEN-LAST:event_jPasswordField1ActionPerformed

    private void jLabelCloseMouseClicked(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_jLabelCloseMouseClicked

        System.exit(0);

    }// GEN-LAST:event_jLabelCloseMouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_jLabel3MouseClicked

        this.setState(JFrame.ICONIFIED);

    }// GEN-LAST:event_jLabel3MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed
        String username = LoginUsername.getText().trim();
        String enteredPassword = String.valueOf(jPasswordField1.getPassword());
        loginFeedback.setText(" ");

        if (username.isEmpty() || enteredPassword.isEmpty()) {
            loginFeedback.setText("Enter your username and password to continue.");
            if (username.isEmpty()) {
                LoginUsername.requestFocusInWindow();
            } else {
                jPasswordField1.requestFocusInWindow();
            }
            return;
        }

        if (captcha == null || !captcha.equalsIgnoreCase(captchaResponse.getText().trim())) {
            loginFeedback.setText("Verification code is incorrect. Try again or request a new code.");
            captchaResponse.setText("");
            refreshCaptcha();
            captchaResponse.requestFocusInWindow();
            return;
        }
        refreshCaptcha();

        try (Connection con = Connectionprovider.getCon()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed.");
                return;
            }

            String storedPassword = null;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT password FROM `user` WHERE username = ?")) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        storedPassword = rs.getString("password");
                    }
                }
            }

            boolean authenticated = false;
            boolean legacyPassword = false;

            if (storedPassword != null) {
                if (storedPassword.startsWith("$2a$")
                        || storedPassword.startsWith("$2b$")
                        || storedPassword.startsWith("$2y$")) {
                    try {
                        authenticated = BCrypt.checkpw(enteredPassword, storedPassword);
                    } catch (IllegalArgumentException invalidHash) {
                        authenticated = false;
                    }
                } else {
                    // Legacy account: compare its existing plain-text password once.
                    authenticated = storedPassword.equals(enteredPassword);
                    legacyPassword = authenticated;
                }
            }

            if (!authenticated) {
                loginFeedback.setText("Username or password is incorrect. A new code is shown above.");
                jPasswordField1.setText("");
                jPasswordField1.requestFocusInWindow();
                return;
            }

            // Migrate a legacy plain-text password to BCrypt after successful
            // authentication.
            if (legacyPassword) {
                String upgradedHash = BCrypt.hashpw(enteredPassword, BCrypt.gensalt(12));
                try (PreparedStatement update = con.prepareStatement(
                        "UPDATE `user` SET password = ? WHERE username = ?")) {
                    update.setString(1, upgradedHash);
                    update.setString(2, username);
                    update.executeUpdate();
                }
            }

            PasswordPage passwordPage = new PasswordPage(username);
            WindowNavigation.replace(this, passwordPage);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginForm.class.getName()).log(Level.SEVERE, "Login failed", ex);
            JOptionPane.showMessageDialog(this, "Login failed due to a database error.");
        }
    }// GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }// GEN-LAST:event_jButton2ActionPerformed

    private void jLabelRegisterMouseClicked(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_jLabelRegisterMouseClicked
        WindowNavigation.showChild(this, new RegisterForm());
    }// GEN-LAST:event_jLabelRegisterMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_jButton1MouseClicked

    }// GEN-LAST:event_jButton1MouseClicked

    private void LoginUsernameActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_LoginUsernameActionPerformed

    }// GEN-LAST:event_LoginUsernameActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jCheckBox1ActionPerformed
        if (jCheckBox1.isSelected()) {
            jPasswordField1.setEchoChar((char) 0);
        } else {
            jPasswordField1.setEchoChar('*');
        }
    }// GEN-LAST:event_jCheckBox1ActionPerformed

    private void refreshCaptcha() {
        StringBuilder code = new StringBuilder(6);
        for (int index = 0; index < 6; index++) {
            code.append(CAPTCHA_CHARACTERS.charAt(CAPTCHA_RANDOM.nextInt(CAPTCHA_CHARACTERS.length())));
        }
        captcha = code.toString();
        captchaLabel.setText(captcha);
        captchaResponse.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        // <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
        // (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the default
         * look and feel.
         * For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        // </editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField LoginUsername;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelClose;
    private javax.swing.JLabel jLabelRegister;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField jPasswordField1;
    // End of variables declaration//GEN-END:variables
}
