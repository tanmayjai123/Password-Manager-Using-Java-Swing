package com;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class PasswordStrengthTest {

    @Test
    public void nullAndEmptyPasswordsAreVeryWeak() {
        assertResult(null, 0, PasswordStrength.Level.VERY_WEAK);
        assertResult("", 0, PasswordStrength.Level.VERY_WEAK);
    }

    @Test
    public void passwordWithOnlyOneCriterionIsVeryWeak() {
        assertResult("password", 1, PasswordStrength.Level.VERY_WEAK);
    }

    @Test
    public void scoreReflectsLengthAndCharacterVariety() {
        assertResult("password1", 2, PasswordStrength.Level.WEAK);
        assertResult("Password123", 3, PasswordStrength.Level.MEDIUM);
        assertResult("Password123!", 5, PasswordStrength.Level.VERY_STRONG);
    }

    @Test
    public void symbolAndUnicodeCharactersAreRecognized() {
        assertResult("abc!", 2, PasswordStrength.Level.WEAK);
        assertResult("éÉ123456789!", 5, PasswordStrength.Level.VERY_STRONG);
        assertResult("Abcdefghi1😀", 4, PasswordStrength.Level.STRONG);
    }

    private void assertResult(String password, int score, PasswordStrength.Level level) {
        PasswordStrength.Result result = PasswordStrength.evaluate(password);
        assertEquals(score, result.getScore());
        assertEquals(level, result.getLevel());
    }
}
