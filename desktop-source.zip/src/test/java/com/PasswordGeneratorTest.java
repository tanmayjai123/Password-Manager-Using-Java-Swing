package com;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class PasswordGeneratorTest {

    @Test
    public void generatedPasswordContainsAtLeastOneCharacterFromEverySelectedGroup() {
        String password = PasswordGenerator.generate(24, true, true, true, true);

        assertEquals(24, password.length());
        assertTrue(password.matches("(?s).*[A-Z].*"));
        assertTrue(password.matches("(?s).*[a-z].*"));
        assertTrue(password.matches("(?s).*[0-9].*"));
        assertTrue(password.matches("(?s).*[^A-Za-z0-9].*"));
    }

    @Test
    public void generatedPasswordOnlyUsesSelectedGroups() {
        String password = PasswordGenerator.generate(24, false, true, true, false);

        assertEquals(24, password.length());
        assertTrue(password.matches("[a-z0-9]+"));
    }

    @Test
    public void rejectsLengthSmallerThanSelectedGroupCount() {
        expectInvalid(2, true, true, true, false);
    }

    @Test
    public void rejectsInvalidLengthAndMissingCharacterGroups() {
        expectInvalid(0, true, false, false, false);
        expectInvalid(10, false, false, false, false);
    }

    private void expectInvalid(
            int length,
            boolean uppercase,
            boolean lowercase,
            boolean digits,
            boolean symbols) {
        try {
            PasswordGenerator.generate(length, uppercase, lowercase, digits, symbols);
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected invalid generator input to be rejected.");
    }
}
