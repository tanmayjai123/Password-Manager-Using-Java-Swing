package com;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class SecurityWordCredentialTest {

    @Test
    public void hashedSecurityWordCanBeVerified() {
        char[] securityWord = "correct horse battery".toCharArray();
        String hash = SecurityWordCredential.hash(securityWord);

        assertTrue(SecurityWordCredential.isHashed(hash));
        assertTrue(SecurityWordCredential.verify(
                "correct horse battery".toCharArray(), hash));
        assertFalse(SecurityWordCredential.verify(
                "incorrect word".toCharArray(), hash));
    }

    @Test
    public void legacyPlainTextCredentialCanBeVerifiedBeforeMigration() {
        assertTrue(SecurityWordCredential.verify(
                " old security word ".toCharArray(), "old security word"));
        assertFalse(SecurityWordCredential.verify(
                "wrong".toCharArray(), "old security word"));
    }
}
