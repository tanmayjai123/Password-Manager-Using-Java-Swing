# Password Manager using Java Swing GUI

A password manager application built with Java Swing that focuses on user privacy and offers various features for securely managing passwords.

## Features

- **User Privacy**: This password manager is designed with user privacy in mind. Passwords are encrypted before being stored in the MySQL database to ensure security.

- **User Registration**: Users can create accounts by registering with a username and a master password.

- **Storing Passwords**: Passwords are securely stored in a MySQL database. The stored passwords are encrypted to protect user data.

- **View Passwords**: Users can view and manage their saved passwords. Passwords are decrypted for the user's convenience when viewing.

- **Update and Delete Passwords**: Edit saved application names, usernames, and passwords, or permanently delete an entry from the password vault.

- **Generate Passwords**: Create strong random passwords and guarantee at least one character from each selected type.

- **Strength Check**: Evaluate password length and character variety locally, with a clear strength meter. The password is not saved or sent by the checker.

- **Text CAPTCHA**: A refreshed text CAPTCHA is required on the login page to help reduce automated sign-in attempts.

- **Password Decryption**: Users can decrypt stored passwords when needed. Decryption requires the master password.

## Technologies Used
- Java Swing for the graphical user interface.
- MySQL for database management.
- NetBeans IDE for development.

## Java Runtime

This project requires JDK 25 (the current Java LTS release) to build and run. Maven compiles the application and tests against the Java 25 API and bytecode level.

## Usage
- Need to create a database with two tables (one for registration & users,other one for storing password)
- Register as a new user and set up your master password.
- Start managing your passwords securely.

## Tests

Run the automated password strength and generator tests with:

```sh
mvn test
```

## Contributions
I welcome contributions from the open-source community. Feel free to submit bug reports, feature requests, or contribute to the development of this project.
